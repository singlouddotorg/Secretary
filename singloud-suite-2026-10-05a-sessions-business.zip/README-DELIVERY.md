# Sing Loud Suite — delivery

Assembled from one working tree. Six apps, each in its own folder, each uploading to its own GitHub repo.

| App | Version | Upload to |
|---|---|---|
| Secretary | 1.0.1 | `singlouddotorg/Secretary` |
| Bibliographer | 0.63.1 | `singlouddotorg/Bibliographer` |
| Capture | 1.0.1 | `singlouddotorg/Simple-Minutes` |
| Compile | 1.0.2 | `singlouddotorg/Simple-Compile` |
| Singing Ledger | 0.1.0 | `singlouddotorg/Ledger` |
| Tunebook Registry | 1.0.1 | `singlouddotorg/Tunebook-Registry` |

Copy each folder's contents into the root of its repo and commit. `MANIFEST.md` lists every file. Nothing was removed. Secretary, and Compile's shared version file, changed. This zip supersedes the earlier 2026-10-04 zips...-h-attendee-present.zip`).

## New in this zip (Secretary 1.0.1)

- **Event Details raw number:** the box is now "Total attendees (raw number) — only if you can't enter everyone's name", with a red note to leave it blank whenever names can be entered. A typed number replaces the counted total on the All-sessions statement and in Minutes Maker.
- **Report:** a singing with more than one session shows a statement per session (named by the session label), then an "All sessions" statement; one session shows just the one statement. Session counts come from the people named in that session's entries or holding an office that session.
- **Business & Announcements** is now a focused editor over the Song List: one box per Business Meeting or announcement entry, each bound to that entry's Notes, so edits show on the Song List and print in the minutes. The page and its menu item appear only once a Business Meeting is entered or an officer makes an announcement. Older free-text business fields show only when a file already holds text in them.
- **Numbered announcements:** when one officer (or one person, if no office) makes more than one announcement in a session, they are labeled "Treasurer announcement 1 of 2" on the Song List and read "made the first announcement" in the minutes. A single announcement stays unnumbered.
- New shipped test: `report-sessions-business`. README and Instructions updated.

## Verification

Shipped tests re-run: 161 tests, all passing (the new ones cover per-session Report statements, the raw-number wording, Business page visibility and editing, and announcement numbering). The full 365-test development suite was not available in this session, so run it before publishing.
Not tested: a real touch device.

## Still open: needs Kevin

CHM2010 compiler, CHD first edition, Temple Star, Shenandoah Harmony date policy, American Harmony year, Harmonia Sacra modeling, Kentucky Harmony / Wyeth duplication, `e_CHW2015` date conflict, Plain Circle Tune Book 1996, Mitchison's thin record, MiH/MoH merge, optional Harmonia Sacra 1993. Queued: Compile "leaderless singing" drops "Number of leaders".
