# Delivery manifest

Assembled 2026-10-04 22:01 UTC from one working tree.

| App | Version | Files | Upload to |
|---|---|---|---|
| Secretary | 1.0.1 | 50 | `singlouddotorg/Secretary` |
| Bibliographer | 0.63.1 | 41 | `singlouddotorg/Bibliographer` |
| Capture | 1.0.1 | 11 | `singlouddotorg/Simple-Minutes` |
| Compile | 1.0.2 | 7 | `singlouddotorg/Simple-Compile` |
| Singing Ledger | 0.1.0 | 6 | `singlouddotorg/Ledger` |
| Tunebook Registry | 1.0.1 | 29 | `singlouddotorg/Tunebook-Registry` |

Every app versions itself. `shared-utils.js` carries its own version (1.2.0),
which is not any application's - Bibliographer vendors that file and must not ship Secretary's
number inside it. Simple Compile shares Secretary's own generation engine (its Compile
logic, copied verbatim - not reimplemented) but tracks its own release number, since
it has its own repo and audience.

## Shared files, and which copies came from where

Every copy below was written by this script from a single source in the working
tree, in one pass, and this build verified them byte-identical before writing this
manifest - see "verify: no drift possible" in build-suite.sh.

- `shared-utils.js` (`15bbef458ce3`): bibliographer/shared-utils.js ledger/shared-utils.js secretary/shared-utils.js simple-compile/shared-utils.js tunebook-registry/shared-utils.js 
- `tunebook-library.js` (`1e5c10868c0c`): bibliographer/tunebook-library.js ledger/tunebook-library.js secretary/tunebook-library.js simple-compile/tunebook-library.js simple-minutes/tests/live/fixtures/tunebook-library.js simple-minutes/tunebook-library.js tunebook-registry/tunebook-library.js 
- `minutes-version.js` (`933ac153a213`): secretary/minutes-version.js simple-compile/minutes-version.js 

## Every file, by app

### secretary
```
LICENSE
README.md
SCHEMA-5.md
index.html
instructions.html
minutes-version.js
samples/american-christmas-harp-singing-2013-12-28.csv
samples/american-christmas-harp-singing-2014-12-27.csv
samples/american-christmas-harp-singing-2015-12-27.csv
samples/bf-white-memorial-sacred-harp-singing-2024-09-15.csv
samples/bf-white-sacred-harp-convention-2017-09-17.csv
samples/bf-white-sacred-harp-convention-2018-09-16.csv
samples/bf-white-sacred-harp-convention-2019-09-15.csv
samples/bf-white-sacred-harp-convention-2022-09-18.csv
samples/bf-white-sacred-harp-convention-2023-09-17.csv
samples/christmas-harp-singing-2017-12-30.csv
samples/christmas-harp-singing-2018-12-29.csv
samples/christmas-harp-singing-2019-12-28.csv
samples/james-river-convention-2025-11-01-minutes.csv
samples/national-sacred-harp-convention-2000.csv
samples/western-massachusetts-convention-1999.csv
shared-utils.js
tests/attendance-and-privacy.test.js
tests/compile-canonical-leader-conflicts.test.js
tests/compile-schema4-validation.test.js
tests/compile-transactional-import.test.js
tests/compile-ui-fixes.test.js
tests/helpers.js
tests/leader-multi-name-autofill.test.js
tests/live/fixtures/simple-minutes-export.csv
tests/live/lib.js
tests/live/paths.js
tests/live/t1-empty-session-delete.js
tests/live/t2-sticky-mode.js
tests/live/t3-no-names.js
tests/live/t4-samples-and-layout.js
tests/live/t5-nameless-detection.js
tests/live/t8-import-ownership.js
tests/minutes-full-title.test.js
tests/minutes-maker-roster-roles.test.js
tests/narrative-markers.test.js
tests/package-lock.json
tests/package.json
tests/reported-number-and-recess.test.js
tests/roundtrip.test.js
tests/setup-open-keeps-officers.test.js
tests/singers-page.test.js
tests/version-provenance.test.js
tests/wrapper-schema5-integrity.test.js
tunebook-library.js
```

### bibliographer
```
LICENSE
README.md
TUNEBOOK-CHANGELOG.md
index.html
shared-utils.js
tests/bulk-edit-integrity.test.js
tests/helpers.js
tests/live/paths.js
tests/live/t9-tunebooks-layout.js
tests/package-lock.json
tests/package.json
tests/tunebooks-core.test.js
tests/tunebooks-level3.test.js
tests/tunebooks-library-sync.test.js
tests/tunebooks-persistence.test.js
tests/v109-review.test.js
tests/v113-review.test.js
tests/v114-review.test.js
tunebook-files/CSH1934.json
tunebook-files/EaI1802.json
tunebook-files/HoA1973.json
tunebook-files/KsH1999.json
tunebook-files/KtH1818.json
tunebook-files/NSH1884.json
tunebook-files/SHB1844.json
tunebook-files/SHD1971.json
tunebook-files/SHM1991.json
tunebook-files/SHM2025.json
tunebook-files/STH1913.json
tunebook-files/ScH1855.json
tunebook-files/ShH2012.json
tunebook-files/SoH1854.json
tunebook-files/UCH1839.json
tunebook-files/UHS1909.json
tunebook-files/UnH1829.json
tunebook-files/VPH2024.json
tunebook-files/WRS1820.json
tunebook-files/WeL1835.json
tunebook-files/WiH1992.json
tunebook-library.js
tunebook-page-extraction-guide.md
```

### simple-minutes
```
LICENSE
README.md
index.html
instructions.html
tests/live/fixtures/tunebook-library.js
tests/live/gen-simple-minutes-fixture.js
tests/live/paths.js
tests/live/t10-simple-minutes-library-safety.js
tests/live/t6-simple-minutes-clock.js
tests/live/t7-break-warnings.js
tunebook-library.js
```

### simple-compile
```
LICENSE
README.md
index.html
instructions.html
minutes-version.js
shared-utils.js
tunebook-library.js
```

### ledger
```
LICENSE
README.md
index.html
instructions.html
shared-utils.js
tunebook-library.js
```

### tunebook-registry
```
LICENSE
README.md
TUNEBOOK-CHANGELOG.md
codes.html
index.html
shared-utils.js
tunebook-files/CSH1934.json
tunebook-files/EaI1802.json
tunebook-files/HoA1973.json
tunebook-files/KsH1999.json
tunebook-files/KtH1818.json
tunebook-files/NSH1884.json
tunebook-files/SHB1844.json
tunebook-files/SHD1971.json
tunebook-files/SHM1991.json
tunebook-files/SHM2025.json
tunebook-files/STH1913.json
tunebook-files/ScH1855.json
tunebook-files/ShH2012.json
tunebook-files/SoH1854.json
tunebook-files/UCH1839.json
tunebook-files/UHS1909.json
tunebook-files/UnH1829.json
tunebook-files/VPH2024.json
tunebook-files/WRS1820.json
tunebook-files/WeL1835.json
tunebook-files/WiH1992.json
tunebook-library.js
tunebook-page-extraction-guide.md
```

