// Secretary — application version.
//
// One literal, in a file small enough to have no other reason to change, loaded by both
// minutes.html and instructions.html so the running app and the page describing it cannot
// disagree. That disagreement is not hypothetical: Instructions once sat six revisions
// behind the app, in exactly the page someone reads while writing a bug report.
//
// This used to live in shared-utils.js, which solved the same problem while every app
// shared one repository. It cannot stay there now: Bibliographer carries its own copy of
// shared-utils.js, and would have been carrying Secretary's version number with it. Each app
// in the Sing Loud Suite versions itself - Simple Minutes has no business being at Secretary's
// number just because they were released together.
//
// Kept as a plain global-scope script, not a module, for the same reason as every other
// file here: `import`/`export` are blocked by browsers on file:// URLs, and this suite's
// whole promise is that you double-click a file and it works.
(function(global){
  "use strict";
  var MINUTES_VERSION = "1.0.0-beta.116"; // 2026-10-04: Minutes Maker closing-roster role checkboxes; new Attendees page (formerly Singers) and top-level Report stage (every name entered, rename/merge, phone+email, mailing-list download; contacts stored as singer.* metadata rows). Earlier, 2026-10-03: 2026-10-03: Leader(s) autofill now restarts after a comma, "and", or "&" (multi-leader entries). Earlier, 2026-09-17: renamed Minutes to Secretary (display name only,
  // per the suite-wide rebrand - repo moved to singlouddotorg/Secretary; the working-tree
  // file minutes.html, this variable name, and the EZMinutesVersion global are unchanged,
  // since Simple Minutes/Simple Compile still read this file as a cross-app contract.
  var api = { VERSION: MINUTES_VERSION, SCHEMA_VERSION: "5" };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else global.EZMinutesVersion = api;
})(typeof window !== "undefined" ? window : this);
